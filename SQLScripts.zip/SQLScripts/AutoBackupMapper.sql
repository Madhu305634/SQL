USE [DBASupport]
GO

:setvar DollarEscape "$"
:setvar BackupLocation ""
:setvar BackupLogin ""
:setvar BackupPassword ""

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[BackupConfig](
	[BackupConfigID] [int] IDENTITY(1,1) NOT NULL,
	[BackupLocation] [nvarchar](500) NULL,
	[BackupLogin] [nvarchar](50) NULL,
	[BackupEncryptedPassword] [nvarchar](2000) NULL,
	[ServiceAccount] [nvarchar](50) NOT NULL,
	[DPAPIMachine] [nvarchar](50) NOT NULL,
	[ModifiedDate] [datetime2](7) NOT NULL CONSTRAINT [DF_BackupConfig_ModifiedDate]  DEFAULT (sysutcdatetime()),
	[TransactionLogRetentionHours] [smallint] NOT NULL CONSTRAINT [DF_BackupConfig_LogRetention]  DEFAULT ((768)),
	[DifferentialRetentionHours] [smallint] NOT NULL CONSTRAINT [DF_BackupConfig_DiffRetention]  DEFAULT ((768)),
	[FullRetentionHours] [smallint] NOT NULL CONSTRAINT [DF_BackupConfig_FullRetention]  DEFAULT ((888)),
 CONSTRAINT [PK_BackupConfig_ModifiedDate] PRIMARY KEY CLUSTERED 
(
	[BackupConfigID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

CREATE TRIGGER [dbo].[BackupConfig_ModifiedDate_Update]
   ON  [dbo].[BackupConfig] 
   AFTER UPDATE
AS 
BEGIN

	SET NOCOUNT ON;

	UPDATE bc
	SET ModifiedDate = SYSUTCDATETIME()
	FROM [dbo].[BackupConfig] bc
	JOIN inserted i on bc.BackupConfigID = i.BackupConfigID

END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[DBA_BackupLocation_GetCredential]
	 @BackupLocation NVARCHAR(500) OUTPUT
	,@BackupLogin NVARCHAR(50) OUTPUT
	,@BackupEncryptedPassword NVARCHAR(2000) OUTPUT
AS
BEGIN

	SET NOCOUNT ON;

	SELECT TOP 1 @BackupLocation = BackupLocation
				,@BackupLogin = BackupLogin
				,@BackupEncryptedPassword = BackupEncryptedPassword
	FROM [dbo].[BackupConfig]
	WHERE	ServiceAccount = SYSTEM_USER
	AND		DPAPIMachine = SERVERPROPERTY('ComputerNamePhysicalNetBIOS')
	ORDER BY BackupConfigID DESC;

END;
GO

USE [msdb]
GO


BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'BackupMapper', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=1, 
		@description=N'Temporary Job to Insert Encrypted Value. If you''re seeing this, you shouldn''t!', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run Stuff', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'[string]$Instance =			"$(DollarEscape)(ESCAPE_DQUOTE(SRVR))"
[string]$BackupLocation =	"$(BackupLocation)"
[string]$BackupLogin	=	"$(BackupLogin)"
[string]$BackupPassword =	''$(BackupPassword)''

$DataConnectionString = "Server=$Instance;Integrated Security=Yes;Database=DBASupport"
$DataConnection = New-Object "System.Data.SqlClient.SqlConnection" ($DataConnectionString)
$DataConnection.Open()

$SecurePassword = $BackupPassword | ConvertTo-SecureString -AsPlainText -Force

$SecurePasswordString = $SecurePassword | ConvertFrom-SecureString

$CommitQuery = "INSERT [dbo].[BackupConfig] (BackupLocation, BackupLogin, BackupEncryptedPassword, ServiceAccount, DPAPIMachine)
				VALUES (`''$BackupLocation`'', `''$BackupLogin`'', `''$SecurePasswordString`'', SYSTEM_USER, CONVERT(NVARCHAR(50), SERVERPROPERTY(''ComputerNamePhysicalNetBIOS'')))"

$BackupConfigCommit = New-Object "System.Data.SqlClient.SqlCommand"
$BackupConfigCommit.CommandTimeout = 20
$BackupConfigCommit.Connection = $DataConnection
$BackupConfigCommit.CommandType = [System.Data.CommandType]::Text
$BackupConfigCommit.CommandText = $CommitQuery
if($DataConnection.State -eq "Open") {$BackupConfigCommit.ExecuteNonQuery() > $null}
else{$DataConnection.Open()
     $BackupConfigCommit.ExecuteNonQuery() > $null}
$DataConnection.Close()', 
		@database_name=N'master', 
		@flags=8
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

USE [msdb]
GO


BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBA - Backup Location Mapper', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Backups for this Instance reside with Cross-Domain boundary authentication. This process is designed to run at SQL Server Agent start, but can be run again to re-map the SQL Server process to the destination.

Changes to this job do not affect the mapping. Please refer to the documentation on how to change the mapping.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute]    Script Date: 5/17/2018 3:46:41 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'$Instance = "$(DollarEscape)(ESCAPE_DQUOTE(SRVR))"

$DataConnectionString = "Server=$Instance;Integrated Security=Yes;Database=DBASupport"
$DataConnection = New-Object "System.Data.SqlClient.SqlConnection" ($DataConnectionString)
$DataConnection.Open()

$BackupLocationParameter = New-Object "System.Data.SqlClient.SqlParameter";
$BackupLocationParameter.ParameterName = "@BackupLocation";
$BackupLocationParameter.Direction = [System.Data.ParameterDirection]''Output'';
$BackupLocationParameter.DbType = [System.Data.DbType]''String'';
$BackupLocationParameter.Size = 500;
$BackupLoginParameter = New-Object "System.Data.SqlClient.SqlParameter";
$BackupLoginParameter.ParameterName = "@BackupLogin";
$BackupLoginParameter.Direction = [System.Data.ParameterDirection]''Output'';
$BackupLoginParameter.DbType = [System.Data.DbType]''String'';
$BackupLoginParameter.Size = 50;
$BackupEncryptedPasswordParameter = New-Object "System.Data.SqlClient.SqlParameter";
$BackupEncryptedPasswordParameter.ParameterName = "@BackupEncryptedPassword";
$BackupEncryptedPasswordParameter.Direction = [System.Data.ParameterDirection]''Output'';
$BackupEncryptedPasswordParameter.DbType = [System.Data.DbType]''String'';
$BackupEncryptedPasswordParameter.Size = 2000;

$BackupConfigRead = New-Object "System.Data.SqlClient.SqlCommand"
$BackupConfigRead.CommandTimeout = 20
$BackupConfigRead.Connection = $DataConnection
$BackupConfigRead.CommandType = [System.Data.CommandType]::StoredProcedure
$BackupConfigRead.Parameters.Add($BackupLocationParameter) > $null
$BackupConfigRead.Parameters.Add($BackupLoginParameter) > $null
$BackupConfigRead.Parameters.Add($BackupEncryptedPasswordParameter) > $null
$BackupConfigRead.CommandText = "dbo.DBA_BackupLocation_GetCredential"
if($DataConnection.State -eq "Open") {$BackupConfigRead.ExecuteNonQuery() > $null}
else{$DataConnection.Open()
     $BackupConfigRead.ExecuteNonQuery() > $null}

$BackupLocation = $BackupConfigRead.Parameters["@BackupLocation"].Value
$BackupLogin = $BackupConfigRead.Parameters["@BackupLogin"].Value
$BackupEncryptedPassword = $BackupConfigRead.Parameters["@BackupEncryptedPassword"].Value
$BackupPassword = $BackupEncryptedPassword | ConvertTo-SecureString
$BackupPasswordString = (New-Object System.Management.Automation.PSCredential "user", $BackupPassword).GetNetworkCredential().Password

$BackupConfigQueryText = "DECLARE	 @AdvOpt BIT
		,@XPCmd BIT
		,@BackupLocation NVARCHAR(500)	= N''$BackupLocation''
		,@BackupLogin NVARCHAR(50)		= N''$BackupLogin''
		,@BackupPassword NVARCHAR(500)	= N''$BackupPasswordString''
		,@BackupCommand NVARCHAR(2000)

SET NOCOUNT ON

SELECT @AdvOpt = CONVERT(INT, ISNULL(value, value_in_use))
FROM  sys.configurations
WHERE  name = N''show advanced options'' 

SELECT @XPCmd = CONVERT(INT, ISNULL(value, value_in_use))
FROM  sys.configurations
WHERE  name = N''xp_cmdshell'' 

IF @AdvOpt <> 1
BEGIN

EXEC sp_configure ''show advanced options'', 1
RECONFIGURE WITH OVERRIDE

END

IF @XPCmd <> 1
BEGIN

EXEC sp_configure ''xp_cmdshell'', 1
RECONFIGURE WITH OVERRIDE

END

SET @BackupCommand = N''net use '' + @BackupLocation + '' /d''

EXEC xp_cmdshell @BackupCommand

SET @BackupCommand = N''net use '' + @BackupLocation + '' /user:'' + @BackupLogin + '' '' + @BackupPassword + '' /persist:yes''

EXEC xp_cmdshell @BackupCommand

IF @XPCmd = 0
BEGIN

EXEC sp_configure ''xp_cmdshell'', 0
RECONFIGURE WITH OVERRIDE

END

IF @AdvOpt = 0
BEGIN

EXEC sp_configure ''show advanced options'', 0
RECONFIGURE WITH OVERRIDE

END;
"
$BackupConfigQuery
$BackupConfigQuery = New-Object "System.Data.SqlClient.SqlCommand"
$BackupConfigQuery.CommandTimeout = 20
$BackupConfigQuery.Connection = $DataConnection
$BackupConfigQuery.CommandType = [System.Data.CommandType]::Text
$BackupConfigQuery.CommandText = $BackupConfigQueryText
if($DataConnection.State -eq "Open") {$BackupConfigQuery.ExecuteNonQuery() > $null}
else{$DataConnection.Open()
     $BackupConfigQuery.ExecuteNonQuery() > $null}
$DataConnection.Close()', 
		@database_name=N'master', 
		@flags=8
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Agent Start', 
		@enabled=1, 
		@freq_type=64, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20171212, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

USE [msdb]
GO


BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBA - Backup Cleanup', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Attempts to remove SQL Backup files in the currently specificed global Backup Location. Configurable retention through DBASupport.dbo.BackupConfig.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run Script', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SET NOCOUNT ON;

DECLARE	 @AdvOpt BIT
		,@XPCmd BIT
		,@FullRetentionHours SMALLINT
		,@BackupLocation NVARCHAR(500)
		,@BackupLocationRoot NVARCHAR(500)
		,@Command NVARCHAR(1000)
		,@AGServerNameFolder NVARCHAR(50)
		,@ClusterName NVARCHAR(50)

SELECT @AdvOpt = CONVERT(INT, ISNULL(value, value_in_use))
FROM  sys.configurations
WHERE  name = N''show advanced options'' 

SELECT @XPCmd = CONVERT(INT, ISNULL(value, value_in_use))
FROM  sys.configurations
WHERE  name = N''xp_cmdshell'' 

IF @AdvOpt <> 1
BEGIN

EXEC sp_configure ''show advanced options'', 1
RECONFIGURE WITH OVERRIDE

END

IF @XPCmd <> 1
BEGIN

EXEC sp_configure ''xp_cmdshell'', 1
RECONFIGURE WITH OVERRIDE

END

IF EXISTS (SELECT 1 FROM [DBASUPPORT].[sys].[objects] WHERE [name] = N''BackupConfig'')
BEGIN
	--Get Retention/Location Data
	SELECT TOP 1 @FullRetentionHours = FullRetentionHours
	FROM [DBASupport].[dbo].[BackupConfig]
	ORDER BY [BackupConfigID] DESC
END

--Handle non-populated BackupLocation Values
IF @BackupLocationRoot IS NULL
BEGIN
	EXEC  master.dbo.xp_instance_regread  N''HKEY_LOCAL_MACHINE'', N''Software\Microsoft\MSSQLServer\MSSQLServer'',N''BackupDirectory'', @BackupLocationRoot OUTPUT, ''no_output''
END
ELSE IF @BackupLocationRoot = ''''
BEGIN
	EXEC  master.dbo.xp_instance_regread  N''HKEY_LOCAL_MACHINE'', N''Software\Microsoft\MSSQLServer\MSSQLServer'',N''BackupDirectory'', @BackupLocationRoot OUTPUT, ''no_output''
END

IF SERVERPROPERTY (''IsHadrEnabled'') = 1
BEGIN

SELECT @ClusterName = cluster_name FROM master.sys.dm_hadr_cluster

SELECT TOP 1
   @AGServerNameFolder = @ClusterName + N''`$'' + AGC.name
FROM
 sys.availability_groups_cluster AS AGC
  INNER JOIN sys.dm_hadr_availability_replica_cluster_states AS RCS
   ON
    RCS.group_id = AGC.group_id
  INNER JOIN sys.dm_hadr_availability_replica_states AS ARS
   ON
    ARS.replica_id = RCS.replica_id
  INNER JOIN sys.availability_group_listeners AS AGL
   ON
    AGL.group_id = ARS.group_id
END

--Add Hallengren Instance Syntax on Path
SET @BackupLocationRoot = CASE RIGHT(@BackupLocationRoot, 1) WHEN N''\''
							   THEN LEFT(@BackupLocationRoot, LEN(@BackupLocationRoot) - 1)
						  ELSE @BackupLocationRoot END
SET @BackupLocation = @BackupLocationRoot + N''\'' + REPLACE(@@SERVERNAME, N''\'', N''`$'')

--Handle non-populated Retention Value
IF @FullRetentionHours <= 887
BEGIN
	SET @FullRetentionHours = 888
	PRINT N''An attempt at removing backups less than 37 days old was attempted. This is a hard coded maximum cleanup value. To clean up Backups younger than 5 weeks, you will need to perform this manually.''
	PRINT N''Full Retention set to 888 Hours for this session.''
END

IF @FullRetentionHours IS NULL
BEGIN
	SET @FullRetentionHours = 888
	PRINT N''An attempt at removing backups less than 37 days old was attempted. This is a hard coded maximum cleanup value. To clean up Backups younger than 5 weeks, you will need to perform this manually.''
	PRINT N''Full Retention set to 888 Hours for this session.''
END

SET @Command = N''powershell.exe -NonInteractive -Command "Get-ChildItem -Recurse -Path \"'' + @BackupLocation + ''\" -Include *.trn, *.bak | ? {$_.LastWriteTime -lt (([DateTime]::Now).AddHours(-'' + CAST(@FullRetentionHours AS NVARCHAR(5)) + ''))} | Remove-Item"''

exec xp_cmdshell @Command

IF @AGServerNameFolder IS NOT NULL
BEGIN

	SET @BackupLocation = @BackupLocationRoot + N''\'' + @AGServerNameFolder

	SET @Command = N''powershell.exe -NonInteractive -Command "Get-ChildItem -Recurse -Path \"'' + @BackupLocation + ''\" -Include *.trn, *.bak | ? {$_.LastWriteTime -lt (([DateTime]::Now).AddHours(-'' + CAST(@FullRetentionHours AS NVARCHAR(5)) + ''))} | Remove-Item"''

	exec xp_cmdshell @Command

END

IF @XPCmd = 0
BEGIN

EXEC sp_configure ''xp_cmdshell'', 0
RECONFIGURE WITH OVERRIDE

END

IF @AdvOpt = 0
BEGIN

EXEC sp_configure ''show advanced options'', 0
RECONFIGURE WITH OVERRIDE

END;', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Backup Cleanup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20200925, 
		@active_end_date=99991231, 
		@active_start_time=190500, 
		@active_end_time=235959, 
		@schedule_uid=N'169c18f7-4a78-4cc5-b336-aedf4def2882'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO
