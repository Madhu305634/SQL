USE [DBASupport]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AuditJobChanges](
	[AuditChangeID] [numeric](18, 0) IDENTITY(1,1) NOT NULL,
	[AuditChangeDate] [datetime] NOT NULL,
	[AuditChangeType] [varchar](4) NOT NULL,
	[AuditChangePerformedBy] [nvarchar](256) NOT NULL,
	[ApplicationName] [nvarchar](128) NOT NULL,
	[HostName] [nvarchar](128) NOT NULL,
	[SchemaName] [sysname] NOT NULL,
	[ObjectName] [sysname] NOT NULL,
	[XML_RECSET] [xml] NULL,
 CONSTRAINT [PK_AJC_AuditChangeID] PRIMARY KEY CLUSTERED 
(
	[AuditChangeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[AuditJobChanges] ADD  CONSTRAINT [DF_AJC_AuditChangeDate]  DEFAULT (getdate()) FOR [AuditChangeDate]
GO
ALTER TABLE [dbo].[AuditJobChanges] ADD  CONSTRAINT [DF_AJC_AuditChangeType]  DEFAULT ('?') FOR [AuditChangeType]
GO
ALTER TABLE [dbo].[AuditJobChanges] ADD  CONSTRAINT [DF_AJC_AuditChangePerformedBy]  DEFAULT (coalesce(suser_sname(),'?')) FOR [AuditChangePerformedBy]
GO
ALTER TABLE [dbo].[AuditJobChanges] ADD  CONSTRAINT [DF_AJC_ApplicationName]  DEFAULT (coalesce(app_name(),'?')) FOR [ApplicationName]
GO




USE [DBASupport]
GO

SET ANSI_NULLS ON
GO

SET ANSI_PADDING ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SQLAUDIT_HISTORY](
	[event_time] [datetime2](7) NOT NULL,
	[action_id] [varchar](4) NULL,
	[server_principal_name] [nvarchar](128) NULL,
	[database_name] [nvarchar](128) NULL,
	[object_name] [nvarchar](128) NULL,
	[statement] [nvarchar](max) NULL,
	[dw] [char](1) NULL
) ON [PRIMARY]
GO


CREATE NONCLUSTERED INDEX [NC_DW] ON [dbo].[SQLAUDIT_HISTORY]
(
	[dw] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [NC_EventTime] ON [dbo].[SQLAUDIT_HISTORY]
(
	[event_time] DESC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO



USE [master]
GO

--drop table #tempInstanceNames

DECLARE @sqlCommand varchar(1000)
DECLARE @AuditFolder varchar(255)

-- Create audit folders


IF (SELECT substring(CONVERT(VARCHAR(128),SERVERPROPERTY ('productversion')),0,charindex('.', CONVERT(VARCHAR(128),SERVERPROPERTY ('productversion'))))
) = 10 
BEGIN

  CREATE TABLE #tempInstanceNames
  (    InstanceName      NVARCHAR(100),
  	 RegPath           NVARCHAR(100),
      DefaultDataPath   NVARCHAR(MAX)
  )
 
  INSERT INTO #tempInstanceNames (InstanceName, RegPath)
  EXEC   master..xp_instance_regenumvalues
         @rootkey = N'HKEY_LOCAL_MACHINE',
         @key     = N'SOFTWARE\\Microsoft\\Microsoft SQL Server\\Instance Names\\SQL'

  DECLARE     @SQL VARCHAR(MAX)
  SET         @SQL = 'DECLARE @returnValue NVARCHAR(100)'
  SELECT @SQL = @SQL + CHAR(13) +
  'EXEC   master.dbo.xp_regread
  @rootkey      = N''HKEY_LOCAL_MACHINE'',
  @key          = N''SOFTWARE\Microsoft\Microsoft SQL Server\' + RegPath + '\MSSQLServer'',
  @value_name   = N''DefaultLog'',
  @value        = @returnValue OUTPUT;
 

  UPDATE #tempInstanceNames SET DefaultDataPath = @returnValue
  WHERE RegPath = ''' + RegPath + '''' + CHAR(13) FROM #tempInstanceNames

  EXEC (@SQL)
  SELECT  distinct  @AuditFolder =  DefaultDataPath FROM    #tempInstanceNames 
END
ELSE 
  SELECT @AuditFolder =  CONVERT(varchar(255), SERVERPROPERTY('InstanceDefaultLogPath'))
  
  select @AuditFolder

SET @sqlCommand = 'mkdir "' + @AuditFolder + '\' + 'audit\staging"'
  EXECute master.dbo.xp_cmdshell  @sqlCommand 



--MSSQL Server Audit
SET @sqlCommand = 'CREATE SERVER AUDIT [MSSQL_Server_Audit]'
SET @sqlCommand = @sqlCommand + ' TO FILE '
SET @sqlCommand = @sqlCommand + ' (FILEPATH = ''' + @AuditFolder + '\' + 'audit''' 
SET @sqlCommand = @sqlCommand + ',MAXSIZE = 2 MB ,MAX_ROLLOVER_FILES = 200,RESERVE_DISK_SPACE = ON )'
SET @sqlCommand = @sqlCommand + ' WITH '
SET @sqlCommand = @sqlCommand + ' ( QUEUE_DELAY = 1000 ,ON_FAILURE = CONTINUE ,AUDIT_GUID = ''7e3febb9-448c-45bb-8d4a-68ced2ae2413'') '
SET @sqlCommand = @sqlCommand + ' ALTER SERVER AUDIT [MSSQL_Server_Audit] WITH (STATE = ON) '
EXEC (@sqlCommand)
select @sqlCommand

--MSSQL Specification
---------------------
USE [master]
GO

CREATE SERVER AUDIT SPECIFICATION [MSSQL_Server_Specification]
FOR SERVER AUDIT [MSSQL_Server_Audit]
ADD (SERVER_ROLE_MEMBER_CHANGE_GROUP),
ADD (SERVER_OPERATION_GROUP),
ADD (SERVER_STATE_CHANGE_GROUP),
ADD (APPLICATION_ROLE_CHANGE_PASSWORD_GROUP),
ADD (DATABASE_CHANGE_GROUP)
WITH (STATE = ON)
GO



-- Database MSDB Specification
-------------------------------

USE [msdb]
GO

CREATE DATABASE AUDIT SPECIFICATION [SqlAgentObject_Audit_MSDB]
FOR SERVER AUDIT [MSSQL_Server_Audit]
ADD (EXECUTE ON OBJECT::[dbo].[sp_agent_add_job] BY [public]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_agent_add_job] BY [dbo]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_agent_add_job] BY [SQLAgentUserRole]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_agent_delete_job] BY [public]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_agent_delete_job] BY [dbo]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_agent_delete_job] BY [SQLAgentUserRole]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_agent_add_jobstep] BY [public]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_agent_add_jobstep] BY [dbo]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_agent_add_jobstep] BY [SQLAgentUserRole]),
ADD (DELETE ON OBJECT::[dbo].[sysjobs] BY [public]),
ADD (INSERT ON OBJECT::[dbo].[sysjobs] BY [public]),
ADD (UPDATE ON OBJECT::[dbo].[sysjobs] BY [public]),
ADD (DELETE ON OBJECT::[dbo].[sysjobs] BY [dbo]),
ADD (INSERT ON OBJECT::[dbo].[sysjobs] BY [dbo]),
ADD (UPDATE ON OBJECT::[dbo].[sysjobs] BY [dbo]),
ADD (DELETE ON OBJECT::[dbo].[sysjobs] BY [SQLAgentUserRole]),
ADD (INSERT ON OBJECT::[dbo].[sysjobs] BY [SQLAgentUserRole]),
ADD (UPDATE ON OBJECT::[dbo].[sysjobs] BY [SQLAgentUserRole]),
ADD (DELETE ON OBJECT::[dbo].[sysjobsteps] BY [public]),
ADD (INSERT ON OBJECT::[dbo].[sysjobsteps] BY [public]),
ADD (UPDATE ON OBJECT::[dbo].[sysjobsteps] BY [public]),
ADD (DELETE ON OBJECT::[dbo].[sysjobsteps] BY [dbo]),
ADD (INSERT ON OBJECT::[dbo].[sysjobsteps] BY [dbo]),
ADD (UPDATE ON OBJECT::[dbo].[sysjobsteps] BY [dbo]),
ADD (DELETE ON OBJECT::[dbo].[sysjobsteps] BY [SQLAgentUserRole]),
ADD (INSERT ON OBJECT::[dbo].[sysjobsteps] BY [SQLAgentUserRole]),
ADD (UPDATE ON OBJECT::[dbo].[sysjobsteps] BY [SQLAgentUserRole]),
ADD (DELETE ON OBJECT::[dbo].[sysjobschedules] BY [public]),
ADD (INSERT ON OBJECT::[dbo].[sysjobschedules] BY [public]),
ADD (UPDATE ON OBJECT::[dbo].[sysjobschedules] BY [public]),
ADD (DELETE ON OBJECT::[dbo].[sysjobschedules] BY [dbo]),
ADD (INSERT ON OBJECT::[dbo].[sysjobschedules] BY [dbo]),
ADD (UPDATE ON OBJECT::[dbo].[sysjobschedules] BY [dbo]),
ADD (DELETE ON OBJECT::[dbo].[sysjobschedules] BY [SQLAgentUserRole]),
ADD (INSERT ON OBJECT::[dbo].[sysjobschedules] BY [SQLAgentUserRole]),
ADD (UPDATE ON OBJECT::[dbo].[sysjobschedules] BY [SQLAgentUserRole]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_add_job] BY [public]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_add_job] BY [dbo]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_add_job] BY [SQLAgentUserRole]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_update_job] BY [public]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_update_job] BY [dbo]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_update_job] BY [SQLAgentUserRole]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_delete_job] BY [public]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_delete_job] BY [dbo]),
ADD (EXECUTE ON OBJECT::[dbo].[sp_delete_job] BY [SQLAgentUserRole])
WITH (STATE = ON)
GO


-- By default are included 4  server groups, if needed enable one of disabled here ( mosdt popular for auditing).
-- there is no problem to execute this script if group already exist



use master;
-- disable server audit
ALTER SERVER AUDIT [MSSQL_Server_Audit]  WITH (STATE = OFF) ;
-- Disable server audit specification
ALTER SERVER AUDIT SPECIFICATION [MSSQL_Server_Specification]   WITH (STATE = OFF) ;

-- add/alter additional specifications
ALTER SERVER AUDIT SPECIFICATION [MSSQL_Server_Specification]
FOR SERVER AUDIT [MSSQL_Server_Audit]  
ADD (DATABASE_OBJECT_ACCESS_GROUP)
,ADD (DATABASE_CHANGE_GROUP)
,ADD (SERVER_OPERATION_GROUP)
,ADD (APPLICATION_ROLE_CHANGE_PASSWORD_GROUP)
,ADD (SERVER_STATE_CHANGE_GROUP)
-- ,ADD (DATABASE_ROLE_MEMBER_CHANGE_GROUP)
-- ,ADD (SERVER_ROLE_MEMBER_CHANGE_GROUP)
-- ,ADD (BACKUP_RESTORE_GROUP)
-- ,ADD (AUDIT_CHANGE_GROUP)
-- ,ADD (FAILED_DATABASE_AUTHENTICATION_GROUP)
-- ,ADD (DATABASE_LOGOUT_GROUP)
-- ,ADD (SUCCESSFUL_DATABASE_AUTHENTICATION_GROUP)
-- ,ADD (DBCC_GROUP)
-- ,ADD (FULLTEXT_GROUP)
-- ,ADD (DATABASE_PERMISSION_CHANGE_GROUP)
-- ,ADD (DATABASE_OBJECT_PERMISSION_CHANGE_GROUP)
-- ,ADD (SCHEMA_OBJECT_PERMISSION_CHANGE_GROUP)
-- ,ADD (SERVER_OBJECT_PERMISSION_CHANGE_GROUP)
-- ,ADD (SERVER_PERMISSION_CHANGE_GROUP)
-- ,ADD (DATABASE_PRINCIPAL_IMPERSONATION_GROUP)
-- ,ADD (SERVER_PRINCIPAL_IMPERSONATION_GROUP)
-- ,ADD (BROKER_LOGIN_GROUP)
-- ,ADD (FAILED_LOGIN_GROUP)
-- ,ADD (DATABASE_MIRRORING_LOGIN_GROUP)
-- ,ADD (DATABASE_OBJECT_CHANGE_GROUP)
-- ,ADD (DATABASE_PRINCIPAL_CHANGE_GROUP)
-- ,ADD (SCHEMA_OBJECT_CHANGE_GROUP)
-- ,ADD (SERVER_OBJECT_CHANGE_GROUP)
-- ,ADD (SERVER_PRINCIPAL_CHANGE_GROUP)
-- ,ADD (DATABASE_OPERATION_GROUP)
-- ,ADD (LOGIN_CHANGE_PASSWORD_GROUP)
-- ,ADD (DATABASE_OWNERSHIP_CHANGE_GROUP)
-- ,ADD (DATABASE_OBJECT_OWNERSHIP_CHANGE_GROUP)
-- ,ADD (SCHEMA_OBJECT_OWNERSHIP_CHANGE_GROUP)
-- ,ADD (SERVER_OBJECT_OWNERSHIP_CHANGE_GROUP)
-- ,ADD (TRACE_CHANGE_GROUP)
-- ,ADD (USER_CHANGE_PASSWORD_GROUP)
-- ,ADD (USER_DEFINED_AUDIT_GROUP)
    WITH (STATE = ON);  
GO  

--enable server audit
ALTER SERVER AUDIT [MSSQL_Server_Audit]  WITH (STATE = ON) ;


USE [MSDB]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TRIGGER [dbo].[trig_sysjobs_insert_update_delete]
ON [dbo].[sysjobs]
FOR INSERT, UPDATE, DELETE
AS

BEGIN
  DECLARE @lv_schemaName varchar(25) = 'dbo', @lv_tablename varchar(50) = 'sysjobs'
  DECLARE @sys_usr nvarchar(50) = user_name()
  , @lv_sUserSName nvarchar(50) = suser_sname()
  , @lv_originalLogin nvarchar(50) = original_login()
  , @lv_applicationName nvarchar(50) = app_name()
  , @lv_hostName nvarchar(50) = host_name()
  , @lb_IncludeSystemAutomedUpdates bit = 0

  SELECT @sys_usr = user_name()
  SELECT @lv_sUserSName = suser_sname()
  SELECT @lv_originalLogin = original_login()
  SELECT @lv_applicationName = app_name()
  SELECT @lv_hostName = host_name()


  IF @lv_applicationName <> 'SQLAgent - Job Manager' OR @lb_IncludeSystemAutomedUpdates = 1 BEGIN
    -- Detect inserts
    IF EXISTS (SELECT * from inserted) AND NOT EXISTS (SELECT * from deleted)
    BEGIN
      INSERT INTO  DBASupport.dbo.AuditJobChanges (AuditChangeDate
      , AuditChangeType
      , AuditChangePerformedBy
      , ApplicationName
      , HostName
      , SchemaName
      , ObjectName
      , XML_RECSET
      )
      SELECT getdate()
      , 'INS'
      , @lv_sUserSName
      , @lv_applicationName
      , @lv_hostName
      , @lv_schemaName
      , @lv_tablename
      , XML_RECSET = (SELECT * from inserted for xml path('RecordSet'), TYPE)
    END

    -- Detect deletes
    IF EXISTS (SELECT * from deleted) AND NOT EXISTS (SELECT * from inserted)
    BEGIN
      INSERT INTO  DBASupport.dbo.AuditJobChanges (AuditChangeDate
      , AuditChangeType
      , AuditChangePerformedBy
      , ApplicationName
      , HostName
      , SchemaName
      , ObjectName
      , XML_RECSET
      )
      SELECT getdate()
      , 'DEL'
      , @lv_sUserSName
      , @lv_applicationName
      , @lv_hostName
      , @lv_schemaName
      , @lv_tablename
      , XML_RECSET = (SELECT * from deleted for xml path('RecordSet'), TYPE)
      END
    -- Detect updates
    IF EXISTS (SELECT * from inserted) AND EXISTS (SELECT * from deleted)
    BEGIN
      INSERT INTO  DBASupport.dbo.AuditJobChanges (AuditChangeDate
      , AuditChangeType
      , AuditChangePerformedBy
      , ApplicationName
      , HostName
      , SchemaName
      , ObjectName
      , XML_RECSET
      )
       SELECT getdate()
      , 'UPD'
      , @lv_sUserSName
      , @lv_applicationName
      , @lv_hostName
      , @lv_schemaName
      , @lv_tablename
      , XML_RECSET = (SELECT * from inserted for xml path('RecordSet'), TYPE)
      END
    END
  END
GO

ALTER TABLE [dbo].[sysjobs] ENABLE TRIGGER [trig_sysjobs_insert_update_delete]
GO




USE [msdb]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[trig_sysjobsteps_insert_update_delete]
ON [dbo].[sysjobsteps]
FOR INSERT, UPDATE, DELETE
AS

BEGIN

DECLARE @lv_schemaName varchar(25) = 'dbo', @lv_tablename varchar(50) = 'sysjobsteps'

DECLARE @sys_usr nvarchar(50) = user_name()
, @lv_sUserSName nvarchar(50) = suser_sname()
, @lv_originalLogin nvarchar(50) = original_login()
, @lv_applicationName nvarchar(50) = app_name()
, @lv_hostName nvarchar(50) = host_name()
, @lb_IncludeSystemAutomedUpdates bit = 0

SELECT @sys_usr = user_name()
SELECT @lv_sUserSName = suser_sname()
SELECT @lv_originalLogin = original_login()
SELECT @lv_applicationName = app_name()
SELECT @lv_hostName = host_name()


IF @lv_applicationName <> 'SQLAgent - Job Manager' OR @lb_IncludeSystemAutomedUpdates = 1 BEGIN

	-- Detect inserts
	IF EXISTS (SELECT * from inserted) AND NOT EXISTS (SELECT * from deleted)
	BEGIN

		INSERT INTO  DBASupport.dbo.AuditJobChanges (AuditChangeDate
	, AuditChangeType
	, AuditChangePerformedBy
	, ApplicationName
	, HostName
	, SchemaName
	, ObjectName
	, XML_RECSET
	)
	SELECT getdate()
	, 'INS'
	, @lv_sUserSName
	, @lv_applicationName
	, @lv_hostName
	, @lv_schemaName
	, @lv_tablename
	, XML_RECSET = (SELECT * from inserted for xml path('RecordSet'), TYPE)
	END


	-- Detect deletes
	IF EXISTS (SELECT * from deleted) AND NOT EXISTS (SELECT * from inserted)
	BEGIN

		INSERT INTO  DBASupport.dbo.AuditJobChanges (AuditChangeDate
	, AuditChangeType
	, AuditChangePerformedBy
	, ApplicationName
	, HostName
	, SchemaName
	, ObjectName
	, XML_RECSET
	)
	SELECT getdate()
	, 'DEL'
	, @lv_sUserSName
	, @lv_applicationName
	, @lv_hostName
	, @lv_schemaName
	, @lv_tablename
	, XML_RECSET = (SELECT * from deleted for xml path('RecordSet'), TYPE)

	END


	-- Detect updates
	IF EXISTS (SELECT * from inserted) AND EXISTS (SELECT * from deleted)
	BEGIN

		INSERT INTO  DBASupport.dbo.AuditJobChanges (AuditChangeDate
	, AuditChangeType
	, AuditChangePerformedBy
	, ApplicationName
	, HostName
	, SchemaName
	, ObjectName
	, XML_RECSET
	)
	SELECT getdate()
	, 'UPD'
	, @lv_sUserSName
	, @lv_applicationName
	, @lv_hostName
	, @lv_schemaName
	, @lv_tablename
	, XML_RECSET = (SELECT * from inserted for xml path('RecordSet'), TYPE)
	END
END

END
GO

ALTER TABLE [dbo].[sysjobsteps] ENABLE TRIGGER [trig_sysjobsteps_insert_update_delete]
GO




USE [MSDB]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[trig_sysjobschedules_insert_update_delete]
ON [dbo].[sysjobschedules]
FOR INSERT, UPDATE, DELETE
AS

BEGIN
DECLARE @lv_schemaName varchar(25) = 'dbo', @lv_tablename varchar(50) = 'sysjobschedules'

DECLARE @sys_usr nvarchar(50) = user_name()
, @lv_sUserSName nvarchar(50) = suser_sname()
, @lv_originalLogin nvarchar(50) = original_login()
, @lv_applicationName nvarchar(50) = app_name()
, @lv_hostName nvarchar(50) = host_name()
, @lb_IncludeSystemAutomedUpdates bit = 0

SELECT @sys_usr = user_name()
SELECT @lv_sUserSName = suser_sname()
SELECT @lv_originalLogin = original_login()
SELECT @lv_applicationName = app_name()
SELECT @lv_hostName = host_name()



IF @lv_applicationName <> 'SQLAgent - Job Manager' OR @lb_IncludeSystemAutomedUpdates = 1 BEGIN

	-- Detect inserts
	IF EXISTS (SELECT * from inserted) AND NOT EXISTS (SELECT * from deleted)
	BEGIN

		INSERT INTO  DBASupport.dbo.AuditJobChanges (AuditChangeDate
	, AuditChangeType
	, AuditChangePerformedBy
	, ApplicationName
	, HostName
	, SchemaName
	, ObjectName
	, XML_RECSET
	)
	SELECT getdate()
	, 'INS'
	, @lv_sUserSName
	, @lv_applicationName
	, @lv_hostName
	, @lv_schemaName
	, @lv_tablename
	, XML_RECSET = (SELECT * from inserted for xml path('RecordSet'), TYPE)

	END


	-- Detect deletes
	IF EXISTS (SELECT * from deleted) AND NOT EXISTS (SELECT * from inserted)
	BEGIN

	INSERT INTO  DBASupport.dbo.AuditJobChanges (AuditChangeDate
	, AuditChangeType
	, AuditChangePerformedBy
	, ApplicationName
	, HostName
	, SchemaName
	, ObjectName
	, XML_RECSET
	)
	SELECT getdate()
	, 'DEL'
	, @lv_sUserSName
	, @lv_applicationName
	, @lv_hostName
	, @lv_schemaName
	, @lv_tablename
	, XML_RECSET = (SELECT * from deleted for xml path('RecordSet'), TYPE)
	END


	-- Detect updates
	IF EXISTS (SELECT * from inserted) AND EXISTS (SELECT * from deleted)
	BEGIN
	INSERT INTO  DBASupport.dbo.AuditJobChanges (AuditChangeDate
	, AuditChangeType
	, AuditChangePerformedBy
	, ApplicationName
	, HostName
	, SchemaName
	, ObjectName
	, XML_RECSET
	)
	SELECT getdate()
	, 'UPD'
	, @lv_sUserSName
	, @lv_applicationName
	, @lv_hostName
	, @lv_schemaName
	, @lv_tablename
	, XML_RECSET = (SELECT * from inserted for xml path('RecordSet'), TYPE)
	END
   END
END
GO

ALTER TABLE [dbo].[sysjobschedules] ENABLE TRIGGER [trig_sysjobschedules_insert_update_delete]
GO

---- Load initial data 
-----------------------
USE MSDB
DECLARE @sys_usr varchar(25)

SET @sys_usr = SYSTEM_USER


INSERT INTO  DBASupport.dbo.AuditJobChanges (AuditChangeDate, AuditChangeType, AuditChangePerformedBy, ApplicationName, HostName, SchemaName, ObjectName, XML_RECSET)
 SELECT getdate() as AuditChangeDate
 , 'ORIG' as AuditChangeType
 , @sys_usr as AuditChangePerformedBy
 , 'Microsoft SQL Server Management Studio' as ApplicationName
 , @@SERVERNAME as HostName
 , 'dbo' as SchemaName
 , 'sysjobs' as ObjectName
 , XML_RECSET = (SELECT * from dbo.sysjobs as j2 where j2.job_id = j1.job_id for xml path('RecordSet'), TYPE)
 from dbo.sysjobs as j1;



INSERT INTO  DBASupport.dbo.AuditJobChanges (AuditChangeDate, AuditChangeType, AuditChangePerformedBy, ApplicationName, HostName, SchemaName, ObjectName, XML_RECSET)
 SELECT getdate() as AuditChangeDate
 , 'ORIG' as AuditChangeType
 , @sys_usr as AuditChangePerformedBy
 , 'Microsoft SQL Server Management Studio' as ApplicationName
 , @@SERVERNAME as HostName
 , 'dbo' as SchemaName
 , 'sysjobsteps' as ObjectName
 , XML_RECSET = (SELECT * from dbo.sysjobsteps as j2 where j2.job_id = j1.job_id for xml path('RecordSet'), TYPE)
 from dbo.sysjobsteps as j1;



INSERT INTO  DBASupport.dbo.AuditJobChanges (AuditChangeDate, AuditChangeType, AuditChangePerformedBy, ApplicationName, HostName, SchemaName, ObjectName, XML_RECSET)
 SELECT getdate() as AuditChangeDate
 , 'ORIG' as AuditChangeType
 , @sys_usr as AuditChangePerformedBy
 , 'Microsoft SQL Server Management Studio' as ApplicationName
 , @@SERVERNAME as HostName
 , 'dbo' as SchemaName
 , 'sysjobschedules' as ObjectName
 , XML_RECSET = (SELECT * from dbo.sysjobschedules as j2 where j2.job_id = j1.job_id for xml path('RecordSet'), TYPE)
 from dbo.sysjobschedules as j1;




USE [DBASupport]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [dbo].[MoveAgentAuditDataToSQLAUDIT_HISTORY]
 AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;
                
        -- insert records in Archive table
        INSERT INTO   SQLAUDIT_HISTORY ( [event_time] ,[action_id],[server_principal_name],[database_name],[object_name],[statement])
        SELECT AuditChangeDate,	AuditChangeType, AuditChangePerformedBy, HostName + ' ' + ApplicationName, 
               ObjectName, CAST(XML_RECSET AS nvarchar(4000))
        FROM AuditJobChanges
		WHERE ObjectName <> 'sysjobschedules' and ApplicationName <> 'Schedule Saver'
		
        -- Truncate source table
        TRUNCATE TABLE AuditJobChanges
        COMMIT TRANSACTION;  

      		
    END TRY
    BEGIN CATCH
        -- report exception
       SELECT   
         ERROR_NUMBER() AS ErrorNumber  
        ,ERROR_SEVERITY() AS ErrorSeverity  
        ,ERROR_STATE() AS ErrorState  
        ,ERROR_LINE () AS ErrorLine  
        ,ERROR_PROCEDURE() AS ErrorProcedure  
        ,ERROR_MESSAGE() AS ErrorMessage;  
        
        -- Test if the transaction is uncommittable.  
        IF (XACT_STATE()) = -1  
        BEGIN  
            PRINT  N'The transaction is in an uncommittable state.' +  
                    'Rolling back transaction.'  
            ROLLBACK TRANSACTION;  
        END;  
        
        -- Test if the transaction is committable.  
        IF (XACT_STATE()) = 1  
        BEGIN  
            PRINT N'The transaction is committable.' +  
                'Committing transaction.'  
            COMMIT TRANSACTION;     
        END;  
    END CATCH
END;
GO

USE [msdb]
GO

DECLARE @jobId binary(16)

IF EXISTS (SELECT job_id 
            FROM msdb.dbo.sysjobs_view 
            WHERE name = N'DBA - LoadAuditLogs')
EXEC msdb.dbo.sp_delete_job @job_name=N'DBA - LoadAuditLogs'
                            , @delete_unused_schedule=1


BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END


EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBA - LoadAuditLogs', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'SQLSupport', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback


EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'LoadFromFiles', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
USE  DBASupport

EXEC  [DBASupport].[dbo].[SqlAuditCaptureAuditLogs]


-- keep for 90 days 
DELETE FROM   [DBASupport].[dbo].SQLAUDIT_HISTORY
WHERE event_time  <  GETDATE() - 90
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'LoadEvery15', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=15, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20191107, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'ba6c06e8-5473-4568-a485-d88fd04ce964'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

USE msdb ;  
GO  

EXEC dbo.sp_update_job  
    @job_name = N'DBA - LoadAuditLogs',  
    @enabled = 1 ;  
GO  

USE [DBASupport]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[SqlAuditCaptureAuditLogs]
AS
BEGIN
	SET XACT_ABORT ON

	DECLARE @sqlCommand varchar(1000)
	DECLARE @AuditFolder varchar(255)
	DECLARE @ExpFile varchar(500)

---------

IF (SELECT substring(CONVERT(VARCHAR(128),SERVERPROPERTY ('productversion')),0,charindex('.', CONVERT(VARCHAR(128),SERVERPROPERTY ('productversion'))))
) = 10 
BEGIN

  CREATE TABLE #tempInstanceNames
  (    InstanceName      NVARCHAR(100),
  	 RegPath           NVARCHAR(100),
      DefaultDataPath   NVARCHAR(MAX)
  )
 
  INSERT INTO #tempInstanceNames (InstanceName, RegPath)
  EXEC   master..xp_instance_regenumvalues
         @rootkey = N'HKEY_LOCAL_MACHINE',
         @key     = N'SOFTWARE\\Microsoft\\Microsoft SQL Server\\Instance Names\\SQL'

  DECLARE     @SQL VARCHAR(MAX)
  SET         @SQL = 'DECLARE @returnValue NVARCHAR(100)'
  SELECT @SQL = @SQL + CHAR(13) +
  'EXEC   master.dbo.xp_regread
  @rootkey      = N''HKEY_LOCAL_MACHINE'',
  @key          = N''SOFTWARE\Microsoft\Microsoft SQL Server\' + RegPath + '\MSSQLServer'',
  @value_name   = N''DefaultLog'',
  @value        = @returnValue OUTPUT;
 

  UPDATE #tempInstanceNames SET DefaultDataPath = @returnValue
  WHERE RegPath = ''' + RegPath + '''' + CHAR(13) FROM #tempInstanceNames

  EXEC (@SQL)
  SELECT  distinct  @AuditFolder =  DefaultDataPath FROM    #tempInstanceNames 
END
ELSE 
  SELECT @AuditFolder =  CONVERT(varchar(255), SERVERPROPERTY('InstanceDefaultLogPath'))
  

---------


	SET @sqlCommand = 'powershell.exe "Move-Item ''' + @AuditFolder + '\audit\*.sqlaudit'' ''' + @AuditFolder + '\audit\staging\'' -ErrorAction SilentlyContinue"'
        EXEC master.dbo.xp_cmdshell @sqlCommand   ,no_output
	

    SET @sqlCommand = @AuditFolder + '\audit\staging\*.*'
		
    INSERT INTO  [dbo].[SQLAUDIT_HISTORY] (
        event_time
        ,action_id
        ,server_principal_name
        ,database_name
        ,object_name
        ,statement )

    SELECT event_time
        ,action_id
        ,server_principal_name
        ,database_name
        ,object_name
        ,statement
	FROM sys.fn_get_audit_file(@sqlCommand, DEFAULT, DEFAULT)
	WHERE action_id not in ('VSST','DBCC','BAL','VDST','SN','ADBO','BRDB')
		AND database_name <> 'tempdb'
		AND statement NOT LIKE 'CREATE TABLE%'
		AND statement NOT LIKE 'DROP TABLE%[_]%[_]%[_]%[_]%'  
		AND statement NOT LIKE 'DROP TABLE%-%-%-%-%'
		AND statement NOT LIKE 'TRUNCATE%-%-%-%-%'  
	 	AND statement NOT LIKE 'TRUNCATE%[_]%[_]%[_]%[_]%' 
		AND statement NOT LIKE 'TRUNCATE%' and server_principal_name <> 'eddsdbo' 
		AND statement <> '-- Encrypted text'
                AND statement NOT LIKE 'ALTER%-%-%-%' 
		AND statement NOT LIKE 'UPDATE STATISTICS%' 
		AND statement NOT LIKE 'CREATE CLUSTERED%' 
                AND server_principal_name  NOT LIKE 'NT SERVICE%'
		AND ( statement NOT LIKE 'DROP TABLE%TEMP%'  AND object_name NOT LIKE 'TEMP[_]%')
		AND ( statement NOT LIKE 'DROP TABLE%TEMP%'  AND object_name NOT LIKE 'TEMP[_]%')
		AND ( statement NOT LIKE 'UPDATE [msdb].[dbo].[sysjobsteps]%' AND server_principal_name NOT LIKE '%svc[_]%' )
		AND ( statement NOT LIKE 'DROP TABLE%MP_ConvertMassOp%' AND  server_principal_name <> 'RelativityScriptLogin' )
   
   	
	 SET @sqlCommand = 'powershell.exe "Remove-Item ''' + @AuditFolder + '\audit\staging\*.*'' -ErrorAction SilentlyContinue"'

	EXEC master.dbo.xp_cmdshell @sqlCommand   ,no_output
END
GO





